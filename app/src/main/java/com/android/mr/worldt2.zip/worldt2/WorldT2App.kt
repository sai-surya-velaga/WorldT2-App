package com.android.mr.worldt2

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class WorldT2App : Application()